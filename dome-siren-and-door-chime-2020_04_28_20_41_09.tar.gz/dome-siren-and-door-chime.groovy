/**
 *  Dome Siren and Door Chime
 *
 *  Copyright 2020 Ben Godsell
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
definition(
    name: "Dome Siren and Door Chime",
    namespace: "bcoleg",
    author: "Ben Godsell",
    description: "App using Dome Wireless Z-Wave Plus Siren created by krlaframboise (github).  Allows sensors to activate a chime, siren or switch on Open Event",
    category: "Safety & Security",
    iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
    iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
    iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png")


preferences {
	section ("Select Contact Sensor") {
		input "contact1", "capability.contactSensor", title: "Where?", multiple: true, required: true
	}
    section("Siren"){
    	input "thesiren", "capability.alarm"}
	section("Use this tone"){
    	input name:"alertTone", type: "enum", title: "Select Alert Tone-", options: ["Chime 1","Chime 2","Chime 3","Bell 1","Bell 2","Bell 3","Bell 4","Bell 5","Siren 1","Siren 2"], description: "Tap to set", required: true
       }
}

def installed()
{
	subscribe(contact1, "contact.open", contactOpenHandler)
}

def updated()
{
	unsubscribe()
	subscribe(contact1, "contact.open", contactOpenHandler)
}

def contactOpenHandler(evt) {
    log.debug "contactOpenHandler called: $evt"
    log.debug "contactOpenHandler called: $alertTone"
	switch(alertTone)
    {
    	case "Bell 5":
        	thesiren.bell5();
            delay(3);
            thesiren.off();
        case "Chime 1":
        	thesiren.chime1();
            delay(3);
            thesiren.off();
        case "Chime 2":
        	thesiren.chime2();
            delay(3);
            thesiren.off();
        case "Chime 3":
        	thesiren.chime3();
            delay(3);
            thesiren.off();
        case "Bell 1":
        	thesiren.bell1();
            delay(3);
            thesiren.off();
        case "Bell 2":
        	thesiren.bell2();
            delay(3);
            thesiren.off();
        case "Bell 3":
        	thesiren.bell3();
            delay(3);
            thesiren.off();
        case "Bell 4":
        	thesiren.bell4();
            delay(3);
            thesiren.off();
        case "Bell 5":
        	thesiren.bell5();
            delay(3);
            thesiren.off();
        case "Siren 1":
        	thesiren.siren1();
            delay(3);
            thesiren.off();
        case "Siren 2":
        	thesiren.siren2();
            delay(3);
            thesiren.off();
        default:
        	thesiren.chime1();
            log.debug "Default Chime"
    }
 }   
def contactClosedHandler(evt) {
    log.debug "contactClosedHandler called: $evt"}


